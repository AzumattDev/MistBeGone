| `Version` | `Update Notes`                                                                                                            |
|-----------|---------------------------------------------------------------------------------------------------------------------------|
| 1.0.2     | - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here. |
| 1.0.1     | - Compile against 0.217.22 version of Valheim                                                                             |
| 1.0.0     | - Initial Release                                                                                                         |