| `Version` | `Update Notes`                                |
|-----------|-----------------------------------------------|
| 1.0.1     | - Compile against 0.217.22 version of Valheim |
| 1.0.0     | - Initial Release                             |